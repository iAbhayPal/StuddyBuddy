# StudyBuddy (Java Web)

A study notes manager built with Java Servlets and JDBC.

## Run
Requires Java 17+ and Maven. From this folder:

    mvn compile exec:java

Open http://localhost:8080

## Rubric mapping
- **Problem understanding & design:** students store lecture/book notes, search them, and get citations.
- **Core Java / OOP:** abstract `Note`, subclasses `LectureNote` and `BookNote` (inheritance, polymorphism), interfaces `Searchable` and `Repository<T, ID>`, custom `NoteException`.
- **Collections & Generics:** `List`, `Map`, `TreeMap`, generic `Repository<T, ID>`.
- **Multithreading & synchronization:** `SearchService` scores notes in parallel with an `ExecutorService`; `synchronized` search statistics.
- **Database classes & JDBC:** `NoteDao` uses `DriverManager`, `PreparedStatement`, `ResultSet` on an H2 database.
- **Servlets:** `NotesServlet` and `StatsServlet` on embedded Tomcat.
