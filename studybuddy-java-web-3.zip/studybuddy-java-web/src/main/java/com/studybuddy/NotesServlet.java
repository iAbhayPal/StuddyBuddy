package com.studybuddy;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/** Servlet: GET lists or searches notes, POST adds or deletes a note. */
public class NotesServlet extends HttpServlet {

    private final NoteDao dao;
    private final SearchService search;

    public NotesServlet(NoteDao dao, SearchService search) {
        this.dao = dao;
        this.search = search;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        String q = req.getParameter("q");
        try {
            StringBuilder sb = new StringBuilder("[");
            if (q != null && !q.isBlank()) {
                List<SearchService.Result> results = search.search(q);
                for (int i = 0; i < results.size(); i++) {
                    if (i > 0) sb.append(',');
                    sb.append(Json.note(results.get(i).note(), results.get(i).score()));
                }
            } else {
                List<Note> notes = dao.findAll();
                for (int i = 0; i < notes.size(); i++) {
                    if (i > 0) sb.append(',');
                    sb.append(Json.note(notes.get(i), 0));
                }
            }
            resp.getWriter().write(sb.append(']').toString());
        } catch (NoteException e) {
            error(resp, 500, e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");
        try {
            if ("delete".equals(req.getParameter("action"))) {
                boolean ok = dao.delete(Integer.parseInt(req.getParameter("id")));
                resp.getWriter().write("{\"ok\":" + ok + "}");
                return;
            }
            int page = 0;
            try {
                page = Integer.parseInt(req.getParameter("page"));
            } catch (NumberFormatException ignored) {
                // page is optional
            }
            Note note = Note.of(req.getParameter("kind"), 0, req.getParameter("title"),
                    req.getParameter("subject"), req.getParameter("content"), page);
            Note saved = dao.save(note);
            resp.getWriter().write("{\"ok\":true,\"id\":" + saved.id() + "}");
        } catch (NoteException e) {
            error(resp, 400, e.getMessage());
        } catch (NumberFormatException e) {
            error(resp, 400, "Invalid id.");
        }
    }

    private void error(HttpServletResponse resp, int code, String msg) throws IOException {
        resp.setStatus(code);
        resp.getWriter().write("{\"error\":\"" + Json.esc(msg) + "\"}");
    }
}
