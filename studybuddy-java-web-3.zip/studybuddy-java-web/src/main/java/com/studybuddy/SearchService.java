package com.studybuddy;

import java.util.*;
import java.util.concurrent.*;

/** Searches notes in parallel (multithreading) and keeps thread-safe search statistics. */
public class SearchService {

    public record Result(Note note, double score) {}

    private final NoteDao dao;
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final Map<String, Integer> searchCounts = new HashMap<>();

    public SearchService(NoteDao dao) { this.dao = dao; }

    public List<Result> search(String query) throws NoteException {
        List<Note> notes = dao.findAll();
        List<Callable<Result>> tasks = new ArrayList<>();
        for (Note n : notes) tasks.add(() -> new Result(n, n.score(query)));

        List<Result> results = new ArrayList<>();
        try {
            for (Future<Result> f : pool.invokeAll(tasks)) {
                Result r = f.get();
                if (r.score() > 0) results.add(r);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new NoteException("Search was interrupted", e);
        } catch (ExecutionException e) {
            throw new NoteException("Search failed", e);
        }
        results.sort(Comparator.comparingDouble(Result::score).reversed());
        record(query);
        return results;
    }

    /** synchronized: many request threads may update the map at once. */
    private synchronized void record(String query) {
        searchCounts.merge(query.trim().toLowerCase(), 1, Integer::sum);
    }

    public synchronized Map<String, Integer> stats() {
        return new TreeMap<>(searchCounts);
    }
}
