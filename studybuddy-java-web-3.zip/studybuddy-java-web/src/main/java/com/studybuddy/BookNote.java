package com.studybuddy;

/** Inheritance: a note from a book, cited with its page number. */
public class BookNote extends Note {
    private final int page;

    public BookNote(int id, String title, String subject, String content, int page) {
        super(id, title, subject, content);
        this.page = page;
    }
    @Override public String kind() { return "BOOK"; }
    @Override public int page() { return page; }
    @Override public String citation() { return "Book: " + title() + ", page " + page + " (" + subject() + ")"; }
}
