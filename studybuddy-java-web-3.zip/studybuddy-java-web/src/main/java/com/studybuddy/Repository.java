package com.studybuddy;

import java.util.List;

/** Generic repository interface (Generics). */
public interface Repository<T, ID> {
    T save(T item) throws NoteException;
    List<T> findAll() throws NoteException;
    boolean delete(ID id) throws NoteException;
}
