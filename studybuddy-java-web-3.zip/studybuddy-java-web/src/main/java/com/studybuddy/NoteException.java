package com.studybuddy;

/** Custom checked exception used across the app (exception handling). */
public class NoteException extends Exception {
    public NoteException(String message) { super(message); }
    public NoteException(String message, Throwable cause) { super(message, cause); }
}
