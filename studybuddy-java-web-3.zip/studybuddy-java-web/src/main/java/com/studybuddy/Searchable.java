package com.studybuddy;

/** Interface: anything that can be scored against a search query. */
public interface Searchable {
    double score(String query);
}
