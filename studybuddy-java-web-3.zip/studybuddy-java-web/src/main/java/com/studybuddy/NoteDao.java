package com.studybuddy;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** Database operations class using JDBC (H2 file database, PreparedStatements). */
public class NoteDao implements Repository<Note, Integer> {

    private static final String URL = "jdbc:h2:./studybuddy-db";

    public NoteDao() throws NoteException {
        try (Connection c = connect(); Statement st = c.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS notes ("
                    + "id INT AUTO_INCREMENT PRIMARY KEY, kind VARCHAR(10) NOT NULL, "
                    + "title VARCHAR(200) NOT NULL, subject VARCHAR(100), "
                    + "content VARCHAR(20000), page INT)");
        } catch (SQLException e) {
            throw new NoteException("Could not initialise the database", e);
        }
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, "sa", "");
    }

    @Override
    public Note save(Note n) throws NoteException {
        String sql = "INSERT INTO notes (kind, title, subject, content, page) VALUES (?,?,?,?,?)";
        try (Connection c = connect();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, n.kind());
            ps.setString(2, n.title());
            ps.setString(3, n.subject());
            ps.setString(4, n.content());
            ps.setInt(5, n.page());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                int id = keys.next() ? keys.getInt(1) : 0;
                return Note.of(n.kind(), id, n.title(), n.subject(), n.content(), n.page());
            }
        } catch (SQLException e) {
            throw new NoteException("Could not save the note", e);
        }
    }

    @Override
    public List<Note> findAll() throws NoteException {
        List<Note> list = new ArrayList<>();
        String sql = "SELECT id, kind, title, subject, content, page FROM notes ORDER BY id DESC";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(Note.of(rs.getString("kind"), rs.getInt("id"), rs.getString("title"),
                        rs.getString("subject"), rs.getString("content"), rs.getInt("page")));
            }
        } catch (SQLException e) {
            throw new NoteException("Could not read notes", e);
        }
        return list;
    }

    @Override
    public boolean delete(Integer id) throws NoteException {
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement("DELETE FROM notes WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new NoteException("Could not delete the note", e);
        }
    }
}
