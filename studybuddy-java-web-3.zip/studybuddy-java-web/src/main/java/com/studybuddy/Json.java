package com.studybuddy;

import java.util.Locale;

/** Tiny JSON helpers so no extra library is needed. */
final class Json {
    private Json() {}

    static String esc(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> sb.append(ch < 0x20 ? ' ' : ch);
            }
        }
        return sb.toString();
    }

    static String note(Note n, double score) {
        return "{\"id\":" + n.id()
                + ",\"kind\":\"" + n.kind() + "\""
                + ",\"title\":\"" + esc(n.title()) + "\""
                + ",\"subject\":\"" + esc(n.subject()) + "\""
                + ",\"content\":\"" + esc(n.content()) + "\""
                + ",\"citation\":\"" + esc(n.citation()) + "\""
                + ",\"score\":" + String.format(Locale.ROOT, "%.1f", score) + "}";
    }
}
