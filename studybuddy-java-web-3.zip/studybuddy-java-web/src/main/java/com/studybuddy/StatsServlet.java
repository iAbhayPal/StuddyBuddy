package com.studybuddy;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Map;

/** Servlet: shows how often each query was searched (thread-safe statistics). */
public class StatsServlet extends HttpServlet {
    private final SearchService search;

    public StatsServlet(SearchService search) { this.search = search; }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Integer> e : search.stats().entrySet()) {
            if (!first) sb.append(',');
            sb.append('"').append(Json.esc(e.getKey())).append("\":").append(e.getValue());
            first = false;
        }
        resp.getWriter().write(sb.append('}').toString());
    }
}
