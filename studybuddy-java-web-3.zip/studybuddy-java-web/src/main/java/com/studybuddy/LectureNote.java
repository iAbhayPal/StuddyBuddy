package com.studybuddy;

/** Inheritance: a note taken in a lecture. */
public class LectureNote extends Note {
    public LectureNote(int id, String title, String subject, String content) {
        super(id, title, subject, content);
    }
    @Override public String kind() { return "LECTURE"; }
    @Override public String citation() { return "Lecture: " + title() + " (" + subject() + ")"; }
}
