package com.studybuddy;

import org.apache.catalina.Context;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.servlets.DefaultServlet;
import org.apache.catalina.startup.Tomcat;

import java.io.File;

/** Starts an embedded Tomcat server and registers the servlets. */
public class Main {
    public static void main(String[] args) throws LifecycleException, NoteException {
        NoteDao dao = new NoteDao();
        SearchService search = new SearchService(dao);

        Tomcat tomcat = new Tomcat();
        tomcat.setBaseDir("tomcat-temp");
        tomcat.setPort(8080);
        tomcat.getConnector();

        Context ctx = tomcat.addContext("", new File("webapp").getAbsolutePath());
        Tomcat.addServlet(ctx, "notes", new NotesServlet(dao, search));
        ctx.addServletMappingDecoded("/api/notes", "notes");
        Tomcat.addServlet(ctx, "stats", new StatsServlet(search));
        ctx.addServletMappingDecoded("/api/stats", "stats");
        Tomcat.addServlet(ctx, "default", new DefaultServlet());
        ctx.addServletMappingDecoded("/", "default");
        ctx.addWelcomeFile("index.html");

        tomcat.start();
        System.out.println("StudyBuddy running at http://localhost:8080");
        tomcat.getServer().await();
    }
}
