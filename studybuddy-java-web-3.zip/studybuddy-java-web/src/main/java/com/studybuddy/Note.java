package com.studybuddy;

/** Abstract base class (OOP: abstraction, inheritance, polymorphism). */
public abstract class Note implements Searchable {
    private final int id;
    private final String title;
    private final String subject;
    private final String content;

    protected Note(int id, String title, String subject, String content) {
        this.id = id;
        this.title = title;
        this.subject = subject;
        this.content = content;
    }

    public int id() { return id; }
    public String title() { return title; }
    public String subject() { return subject; }
    public String content() { return content; }

    /** Each subclass describes its own kind and how it is cited (polymorphism). */
    public abstract String kind();
    public abstract String citation();
    public int page() { return 0; }

    @Override
    public double score(String query) {
        double s = 0;
        String body = content.toLowerCase();
        String head = title.toLowerCase();
        for (String w : query.toLowerCase().split("\\W+")) {
            if (w.length() < 2) continue;
            s += count(body, w) + 3 * count(head, w);
        }
        return s;
    }

    private static int count(String text, String word) {
        int c = 0, i = 0;
        while ((i = text.indexOf(word, i)) >= 0) { c++; i += word.length(); }
        return c;
    }

    /** Factory method. */
    public static Note of(String kind, int id, String title, String subject, String content, int page)
            throws NoteException {
        if (title == null || title.isBlank()) throw new NoteException("Title is required.");
        if (content == null || content.isBlank()) throw new NoteException("Content is required.");
        String subj = (subject == null || subject.isBlank()) ? "General" : subject.trim();
        return switch (kind == null ? "" : kind) {
            case "LECTURE" -> new LectureNote(id, title.trim(), subj, content.trim());
            case "BOOK" -> new BookNote(id, title.trim(), subj, content.trim(), page);
            default -> throw new NoteException("Unknown note type: " + kind);
        };
    }
}
